﻿using Lab3;
using Paradygmaty_1.Lab3;

namespace Paradygmaty_1.model
{
    public enum ClientType
    {
        Standard,
        Premium,
        Gold,
    }

    public class Client
    {
        public Rent Rent { get => rent; set => rent = value; }
        private Rent rent;
        private string firstName;
        private string lastName;
        private string personalID;
        private Address address;
        // Komentuje dla zadania 3ego z etapu 2ego.
        //public Client()
        //{
        //    Console.WriteLine("wywołano konstruktor bezparametrowy Client");
        private ClientType clientType;

        //TODO wywal stad rent
        public Client(ClientType clientType, string firstName, string lastName, string personalID, Address address)
        {
            // zmienne zadeklarowane w klasie pola np. rent, firstName są widoczne w metodach
            Console.WriteLine("kostruktor parametrowy Client");
            this.clientType = clientType;
            this.firstName = firstName;
            this.lastName = lastName;
            this.personalID = personalID;
            this.address = address;
        }

        public double CalculateDiscount()
        {
            switch (clientType)
            {
                case ClientType.Premium:
                    // Implementuj logikę dla klienta Premium
                    return 0.1; // upust 10%
                case ClientType.Gold:
                    // Implementuj logikę dla klienta Gold
                    return 0.2; // upust 20%
                                 // Dodaj obsługę innych typów klientów
                default:
                    return 0; // Domyślny upust 0%
            }
        }

        public void ChangeClientType(ClientType newType)
        {
            this.clientType = newType;
        }

        public string GetClientInfo()
        {
            return "Client" + " " + clientType + firstName + " " + lastName + " " + personalID + address.GetInfo() + rent?.GetInfo();
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    firstName = value;
                }

            }
        }
        public string LastName
        {
            get { return lastName; }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    lastName = value;
                }

            }
        }
        public string PersonalID
        {
            get
            {
                return personalID;
            }
        }

        public ClientType ClientType { get; internal set; }
    }
}
