﻿namespace Paradygmaty_1.Execeptions
{
    public abstract class RentException : Exception
    {
        public RentException(string message) : base(message)
        {
        }
    }
}
