﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paradygmaty_1.Execeptions
{
    public class VehicleNotAvailableException : RentException
    {
        public VehicleNotAvailableException() : base("Vehicle is not available")
        {
        }
    }
}
