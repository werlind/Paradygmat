﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.Lab3;

namespace Paradygmaty_1.Execeptions
{
    internal class RentVehicleLimitHasExceededException : RentException
    {
        public RentVehicleLimitHasExceededException() : base("Client rent limit has been exceeded")
        {
        }
    }
}
