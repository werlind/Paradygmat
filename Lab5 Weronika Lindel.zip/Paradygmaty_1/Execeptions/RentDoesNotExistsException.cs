﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paradygmaty_1.Execeptions
{
    public class RentDoesNotExistsException : RentException
    {
        public RentDoesNotExistsException() : base("Rent does not exists")
        {
        }
    }
}
