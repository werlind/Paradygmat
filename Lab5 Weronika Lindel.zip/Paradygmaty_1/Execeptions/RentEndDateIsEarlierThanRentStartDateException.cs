﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paradygmaty_1.Execeptions
{
    public class RentEndDateIsEarlierThanRentStartDateException : RentException
    {
        public RentEndDateIsEarlierThanRentStartDateException() : base("Rent end date is earlier than rent start date")
        {
        }
    }
}
