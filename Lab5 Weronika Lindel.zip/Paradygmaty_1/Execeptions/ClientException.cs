﻿namespace Paradygmaty_1.Execeptions
{
    public abstract class ClientException : Exception
    {
        public ClientException(string message) : base(message)
        {
        }
    }
}
