﻿using System;
using Paradygmaty_1.Lab3;
using Paradygmaty_1.model;

namespace Lab3
{
    public class AutoClient
    {
        public string name;
        private string surname;
        private List<Address> addressList;
        private List<Rent> rents;

        public AutoClient(string name, string surname)
        {
            this.name = name;
            this.surname = surname;
            this.addressList = new List<Address>();
            this.rents = new List<Rent>();
        }

        public void AddRent(Rent rent)
        {
            this.rents.Add(rent);
        }

        public List<Rent> GetRents()
        {
            return this.rents;
        }
        public void AddAddress(Address address)
        {
            this.addressList.Add(address);
        }

        public string GetInfo()
        {
            string input = "Client: " + this.surname + " " + this.name;
            foreach (Address address in this.addressList)
            {
                input += address.GetInfo();
            }
            foreach (Rent rent in this.rents)
            {
                input += rent.GetInfo();
            }
            return input;
        }
    }
}