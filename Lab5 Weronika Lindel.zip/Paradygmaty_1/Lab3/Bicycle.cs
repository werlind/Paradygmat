﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public class Bicycle1 : Vehicle
    {

        public Bicycle1(double vehicleSegment, double baseRentalPrice, string registration) : base(vehicleSegment, baseRentalPrice, registration)
        {
            this.baseRentalPrice = baseRentalPrice;
        }
        public override string Info()
        {
            return "Rower:" + base.Info() + " " + this.baseRentalPrice;
        }
    }
}
