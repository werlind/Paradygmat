﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab3;
using Paradygmaty_1.Lab3;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public class Car : MotorVehicle
    {
        public Car(double vehicleSegment, double engineDisplacement, double baseRentalPrice, string registration)
        : base(registration, vehicleSegment, engineDisplacement, baseRentalPrice)
        {
            this.engineDisplacement = engineDisplacement;
        }
        public override string Info()
        {
            return base.Info() + " " + this.engineDisplacement;
        }
    }
}
