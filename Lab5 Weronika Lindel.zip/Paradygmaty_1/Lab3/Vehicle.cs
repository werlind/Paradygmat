﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public static class VehicleSegment
    {
        public const double A = 1;
        public const double B = 1.1;
        public const double C = 1.2;
        public const double D = 1.3;
        public const double E = 1.5;

    }

    public class Vehicle
    {
        public string registrationNumber;
        public double baseRentalPrice;
        public string bicycle;
        public string moped;
        public string car;
        public string segment;
        public double engineDisplacement;
        public string motorVehicle;
        private double vehicleSegment;
        public double VehicleSegment
        {
            get { return vehicleSegment; }
            set { vehicleSegment = value; }
        }
        public double EngineDisplacement
        {
            get { return engineDisplacement; }
            set { engineDisplacement = value; }
        }
        public string MotorVehicle { get; set; }
        public decimal Price { get; set; }

        public string RegistrationNumber
        {
            get { return registrationNumber; }
            set { registrationNumber = value; }

        }
        public double BaseRentalPrice
        {
            get => baseRentalPrice;
            set => baseRentalPrice = value;
        }

        public Vehicle(double vehicleSegment, double engineDisplacement, double baseRentalPrice, string registration)
        {
            VehicleSegment = vehicleSegment;
            EngineDisplacement = engineDisplacement;
            BaseRentalPrice = baseRentalPrice;
            RegistrationNumber = registration;
        }

        public Vehicle(double vehicleSegment, double baseRentalPrice, string registration)
        {
            VehicleSegment = vehicleSegment;
            BaseRentalPrice = baseRentalPrice;
            RegistrationNumber = registration; 
        }

        public bool IsAvailable { get; set; } = true;

        // Metoda do zmiany dostępności pojazdu
        public void SetAvailability(bool isAvailable)
        {
            IsAvailable = isAvailable;
        }
        public virtual string Info()
        {
            //string interpolation + le code ci-dessous et la meilleure version de " " + etc. 
            return $"Base Rental Price: {BaseRentalPrice}, Engine Displacement: {EngineDisplacement}, vehicle segment: {VehicleSegment}";
        }

    }
}
