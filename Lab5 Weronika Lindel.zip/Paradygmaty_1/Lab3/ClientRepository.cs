﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.model;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{

    internal class ClientRepository
    {
        private List<Client> clients;

        public ClientRepository()
        {
            clients = new List<Client>();
        }

        // Dodaje se klienta do repozytorium
        public void AddClient(Client client)
        {
            clients.Add(client);
        }

        // Usuwam se klienta z repozytorium (po obiekcie klienta)
        public void RemoveClient(Client client)
        {
            clients.Remove(client);
        }

        // supprime le client
        public void RemoveClient(int index)
        {
            if (index >= 0 && index < clients.Count)
            {
                clients.RemoveAt(index);
            }
            else
            {
                Console.WriteLine("Invalid index.");
            }
        }

        // changement de type de client
        public void ChangeClientType(Client client, ClientType newType)
        {
            if (clients.Contains(client))
            {
                client.ChangeClientType(newType);
            }
            else
            {
                Console.WriteLine("Client not found.");
            }
        }

        //j'affiche toutes les infos des clients dans reposi
        public void DisplayAllClientsInfo()
        {
            foreach (var client in clients)
            {
                Console.WriteLine(client.GetClientInfo());
            }
        }
    }
}
