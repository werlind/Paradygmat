﻿using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public class RentsRepository
    {
        private List<Rent> rents = new List<Rent>();

        public void AddRent(Rent rent)
        {
            rents.Add(rent);
        }

        public Rent? GetRentById(Guid id)
        {
            return rents.FirstOrDefault(x => x.RentId == id);
        }

        public void RemoveRent(Rent rent)
        {
            rents.Remove(rent);

        }

        public int GetClientRentCount(Client client)
        {
            return rents.Count(r => r.Client == client);
        }

        public string RentReport()
        {
            string report = "Raport wypożyczeń:";
            foreach (var rent in rents)
            {
                report += $"Klient: {rent.Client.FirstName} {rent.Client.LastName}, Pojazd: {rent.Vehicle.Info()}";
            }

            return report;
        }
    }
}
