﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab3;
using Paradygmaty_1.Execeptions;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public class Rent
    {
        public Guid RentId { get; private set; }
        public DateTime RentStartDateTime { get; private set; }
        public DateTime RentEndDateTime { get; private set; }
        public int RentDuration { get; private set; }
        public double RentCost { get; private set; }
        public Client Client { get; private set; }
        public Vehicle Vehicle { get; private set; }

        public double engineDisplacement;
        public double EngineDisplacement
        {
            get { return engineDisplacement; }
            set { engineDisplacement = value; }
        }
        public double BaseRentalPrice { get; set; }


        public Rent(Client client, Vehicle vehicle, DateTime rentStartDateTime)
        {
            if (rentStartDateTime == DateTime.MinValue) throw new ArgumentNullException(nameof(rentStartDateTime));

            RentId = Guid.NewGuid();
            Client = client ?? throw new ArgumentNullException(nameof(client));
            Vehicle = vehicle ?? throw new ArgumentNullException(nameof(vehicle));
            if (!Vehicle.IsAvailable)
            {
                throw new InvalidOperationException("Pojazd nie jest dostępny.");
            }
            RentStartDateTime = rentStartDateTime;
            RentEndDateTime = DateTime.MinValue;
            RentDuration = 0;
            RentCost = 0;
            Vehicle.SetAvailability(false);
            Vehicle = vehicle ?? throw new ArgumentNullException(nameof(vehicle));
        }


        public void CalculateRentCost()
        {
            if (RentDuration > 0)
            {
                RentCost = RentDuration * Vehicle.BaseRentalPrice - 100 * (1 - Client.CalculateDiscount());
                
            }
        }

        public double CalculateActualRentalPrice()
        {
            double engineFactor = CalculateEngineFactor();
            double segmentFactor = CalculateSegmentFactor();
            return BaseRentalPrice * engineFactor * segmentFactor;
        }

        private double CalculateEngineFactor()
        {
            if (EngineDisplacement < 1000)
            {
                return 1.0;
            }
            else if (EngineDisplacement <= 2000)
            {
                return 1.0 + 0.5 * ((EngineDisplacement - 1000) / 1000);
            }
            else
            {
                return 1.5;
            }
        }

        private double CalculateSegmentFactor()
        {
            return Vehicle.VehicleSegment;
        }


        public void ReturnVehicle(DateTime rentEndDateTime)
        {
            if (rentEndDateTime < RentStartDateTime) throw new RentEndDateIsEarlierThanRentStartDateException();
            if (rentEndDateTime > RentStartDateTime)
            {
                RentEndDateTime = rentEndDateTime;
                RentDuration = (RentEndDateTime - RentStartDateTime).Days;
                CalculateRentCost();
            }

        }

        public string GetInfo()
        {

            return @$"RentId: {RentId}, RentStartDateTime: {RentStartDateTime}, RentEndDateTime: {RentEndDateTime}, 
                    RentDuration: {RentDuration} days, RentCost: {RentCost}, Client: {Client.GetClientInfo()}, Vehicle: {Vehicle.Info()}";
        }
    }
}