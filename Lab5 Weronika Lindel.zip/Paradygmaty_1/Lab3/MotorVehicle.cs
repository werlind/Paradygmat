﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{ 
    public class MotorVehicle : Vehicle
    {
        public MotorVehicle(string registration, double vehicleSegment, double engineDisplacement, double baseRentalPrice) 
            : base(vehicleSegment, engineDisplacement, baseRentalPrice, registration)
        {
            this.engineDisplacement = engineDisplacement;
        }
        public override string Info()
        {
            return base.Info() + " " + this.engineDisplacement;
        }
    }
}
