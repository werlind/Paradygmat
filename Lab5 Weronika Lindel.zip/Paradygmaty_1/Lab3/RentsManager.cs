﻿using Paradygmaty_1.Execeptions;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public class RentsManager
    {
        private RentsRepository archiveRents;
        private RentsRepository currentRents;

        public RentsManager()
        {
            currentRents = new RentsRepository();
            archiveRents = new RentsRepository();
        }

        public void CreateRent(Rent rent)
        {
            if (!IsVehicleAvailable(rent.Vehicle))
            {
                throw new VehicleNotAvailableException();
            }

            if (HasExceededVehicleLimit(rent))
            {
                throw new RentVehicleLimitHasExceededException();
            }

            currentRents.AddRent(rent);
            rent.Vehicle.IsAvailable = false;
        }

        private int GetMaxAllowedRentsForClient(ClientType clientType)
        {
            switch (clientType)
            {
                case ClientType.Premium:
                    return 3;
                case ClientType.Gold:
                    return 5;
                default:
                    return 2;
            }
        }

        private bool IsVehicleAvailable(Vehicle vehicle)
        {
            return vehicle.IsAvailable;
        }

        private bool HasExceededVehicleLimit(Rent rent)
        {
            int maxAllowedRents = GetMaxAllowedRentsForClient(rent.Client.ClientType);
            int currentRentsCount = currentRents.GetClientRentCount(rent.Client);

            return currentRentsCount >= maxAllowedRents;

        }

        public void ReturnVehicle(Rent rent, DateTime rentDateEnd)
        {
            bool isRentExists = currentRents.GetRentById(rent.RentId) != null;
            if (!isRentExists) throw new RentDoesNotExistsException();

            currentRents.RemoveRent(rent);
            rent.Vehicle.IsAvailable = true;
            archiveRents.AddRent(rent);
            rent.ReturnVehicle(rentDateEnd);

            int archiveRentCount = currentRents.GetClientRentCount(rent.Client);
            ClientType clientType = GetClientType(archiveRentCount);
            rent.Client.ChangeClientType(clientType);
        }

        public ClientType GetClientType(int rentCount)
        {
            if (rentCount > 5)
            {
                return ClientType.Gold;
            }
            else if (rentCount > 2)
            {
                return ClientType.Premium;
            }

            return ClientType.Standard;
        }
    }
}

