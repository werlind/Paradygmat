﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.model;

namespace Paradygmaty_1.Lab3
{
    public class VehicleRepository
    {
        private List<Vehicle> vehicles = new List<Vehicle>();
        private Repository vehicles;


        public VehicleRepository()
        {
            vehicles = new List<Vehicle>()
            {
                new Bicycle1(VehicleSegment.E, 2137, "Qraq234"),
                new Bicycle1(VehicleSegment.D, 1456, "Kawka768"),
                new Moped(VehicleSegment.B, 1.3, 563, "poiuy768"),
                new Moped(VehicleSegment.C, 1.5, 567, "LKJ90" ),
                new Moped(VehicleSegment.E, 1.2, 234, "ASDE23"),
                new Moped(VehicleSegment.A, 1.1, 234, "DSAW21"),
                new Car(VehicleSegment.A, 1.3, 324, "GFR56"),
                new Car(VehicleSegment.C, 1.0, 123, "GIJ45"),
                new Car(VehicleSegment.B, 1.2, 200, "GIO90"),
                new Car(VehicleSegment.B, 1.5, 300, "JIJI56"),
            };

        }

        public void AddVehicle(Vehicle vehicle)
        {
            vehicles.Add(vehicle);
        }

        public Vehicle GetVehicleByIndex(int index)
        {
            if (index >= 0 && index < vehicles.Count)
            {
                return vehicles[index];
            }

            return null;
        }

        public string VehicleReport()
        {
            string report = "Raport o pojazdach: ";
            foreach (Vehicle vehicle in vehicles) 
            {
                report += $"{vehicle.Info()} {Environment.NewLine}";
            }

            return report;
        }
    }
}
