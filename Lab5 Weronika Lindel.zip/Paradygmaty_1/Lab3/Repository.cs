﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paradygmaty_1.Lab3
{
    internal class Repository
    {
        private List<Vehicle> vehicles = new List<Vehicle>();




    }
}
