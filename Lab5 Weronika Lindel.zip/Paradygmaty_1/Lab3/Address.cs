﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paradygmaty_1.model;

namespace Lab3
{
    public class Address
    {
        public string city;
        public string street;
        public string houseNumber;

        public string City
        {
            get { return city; }
            set { city = value; }
 
        }
        public string Street
        {
            get { return street; }
            set => street = value;
        }

        public string HouseNumber { get => houseNumber; set => houseNumber = value; }

        public Address(string city, string street, string houseNumber)
        {
            this.city = city;
            this.street = street;
            this.houseNumber = houseNumber;
        }

        public string GetInfo()
        {
            return "Address: " + " " + this.city + " " + this.street + " " + this.houseNumber;

        }
    }
}