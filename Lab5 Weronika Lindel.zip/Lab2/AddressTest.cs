﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankAccountProject;
using Lab3;
using NUnit.Framework;
using Paradygmaty_1.model;

namespace Lab2_Tests_Only
{
    public class AddressTest
    {
        [SetUp]
        public void Setup()
        {
        }


        [Test]
        public void AddressTests()
        {
            Address address = new Address("Krakow", "Wolska", "12");
            Client client = new Client(ClientType.Gold, "Weronika", "Lindel", "49038", address);
            Client client2 = new Client(ClientType.Standard, "Kasia", "Nowak", "12345", address);
            Console.WriteLine(client.GetClientInfo());
            Console.WriteLine(client2.GetClientInfo());

            address.Street = "Grzegorzecka";
            address.HouseNumber = "45";

            Console.WriteLine(client.GetClientInfo());
            Console.WriteLine(client2.GetClientInfo());
        }
    }

}
