﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using Lab3;
using NUnit.Framework;
using Paradygmaty_1.Lab3;
using Paradygmaty_1;
using Paradygmaty_1.model;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using System.Net;
using NUnit.Framework.Constraints;

namespace Inherit_test
{
    internal class Inherit_Test
    {
        private VehicleRepository vehicleRepository;
        private RentsRepository currentRentsRepository;

        [SetUp]
        public void SetUp()
        {
            // Inicjalizacja przed każdym testem
            vehicleRepository = new VehicleRepository();
            currentRentsRepository = new RentsRepository();
        }

        [Test]
        public void RentingUnavailableVehicleFails()
        {
            // Przygotowanie danych
            Client client = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
            Vehicle vehicleToRent = vehicleRepository.GetVehicleByIndex(0);
            DateTime rentStartDateTime = DateTime.Now;

            // Wywołanie testowanej operacji
            Rent rent = new Rent(client, vehicleToRent, rentStartDateTime);
            currentRentsRepository.AddRent(rent);

            // Sprawdzenie oczekiwanych rezultatów
            Assert.IsFalse(vehicleToRent.IsAvailable);
        }

    }

}
