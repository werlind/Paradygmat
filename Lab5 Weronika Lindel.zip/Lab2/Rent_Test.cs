﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab3;
using NUnit.Framework;
using Paradygmaty_1.Lab3;
using Paradygmaty_1.model;

namespace Lab2_Tests_Only
{

    internal class Rent_Test
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void RentTescik()
        {
            Address address = new Address("Krakow", "Wolska", "12");
            Client client = new Client(ClientType.Premium, "Weronika", "Lindel", "49038", address);
            Vehicle vehicle = new Vehicle(VehicleSegment.A, 1000.50, 560.76, "NM5618");
            DateTime dateTime = new DateTime(2023, 07, 23);
            Rent renta = new Rent(client, vehicle, dateTime);
            client.Rent = renta;

            Assert.IsTrue(renta.RentDuration == 0);
            Assert.IsTrue(renta.RentId == client.Rent.RentId);
            renta.ReturnVehicle(new DateTime(2023, 07, 26));
            Assert.IsTrue(renta.RentDuration != 0);
                      
        }



        [Test]
        public void TC1()
        {
            Address address = new Address("Krakow", "Wolska", "12");
            Client client = new Client(ClientType.Gold, "Weronika", "Lindel", "49038", address);
            Vehicle vehicle = new Vehicle(VehicleSegment.A, 1000.50, 560.76, "NM5618");
            DateTime dateTime = new DateTime(2023, 07, 23);
            Rent renta = new Rent(client, vehicle, dateTime);
            client.Rent = renta;

            Assert.IsTrue(renta.RentDuration == 0);
        }

        [Test] 
        public void TC2()
        {
            Address address = new Address("Krakow", "Wolska", "12");
            Client client = new Client(ClientType.Gold, "Weronika", "Lindel", "49038", address);
            Vehicle vehicle = new Vehicle(VehicleSegment.A, 1000.50, 560.76, "NM5618");
            DateTime dateTime = new DateTime(2023, 07, 23);
            Rent renta = new Rent(client, vehicle, dateTime);
            client.Rent = renta;
            renta.ReturnVehicle(new DateTime(2023, 07, 24));
            Assert.IsTrue(renta.RentDuration == 1);
        }

        [Test]
        public void TC3()
        {
            Address address = new Address("Krakow", "Wolska", "12");
            Client client = new Client(ClientType.Standard, "Weronika", "Lindel", "49038", address);
            Vehicle vehicle = new Vehicle(VehicleSegment.A, 1000.50, 560.76, "NM5618");
            DateTime dateTime = new DateTime(2023, 07, 23);
            Rent renta = new Rent(client, vehicle, dateTime);
            client.Rent = renta;
            Assert.Throws<ArgumentOutOfRangeException>(() => renta.ReturnVehicle(new DateTime(2023, 05, 08)));

        }
        [Test]
        public void TC4()
        {
            Address address = new Address("Krakow", "Wolska", "12");
            Client client = new Client(ClientType.Premium, "Weronika", "Lindel", "49038", address);
            Vehicle vehicle = new Vehicle(VehicleSegment.A, 1000.50, 560.76, "NM5618");
            DateTime dateTime = new DateTime(2023, 07, 23);
            Rent renta = new Rent(client, vehicle, dateTime);
            client.Rent = renta;

            renta.ReturnVehicle(new DateTime(2023, 07, 25));
            Assert.IsTrue(renta.RentCost == 1121.52);
        }
    }
}
