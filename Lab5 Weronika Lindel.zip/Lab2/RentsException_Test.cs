﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab3;
using NUnit.Framework;
using Paradygmaty_1.Lab3;
using Paradygmaty_1.model;

namespace Lab2_Tests_Only
{
    internal class RentsException_Test
    {
        internal class RentException
        {
            private VehicleRepository vehicleRepository;
            private RentsRepository currentRentsRepository;

            [SetUp]
            public void SetUp()
            {
                // Inicjalizacja przed każdym testem
                vehicleRepository = new VehicleRepository();
                currentRentsRepository = new RentsRepository();
            }

            [Test]
            public void TC1()
            {
                // Przygotowanie danych
                Client client = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client2 = new Client(ClientType.Standard, "Mojo", "Lolodo", "45366", new Address("Krakow", "Wolska", "12"));
                Client client3 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client4 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client5 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client6 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client7 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client8 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client9 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Client client10 = new Client(ClientType.Standard, "Mojo", "Lolodo", "12345", new Address("Krakow", "Wolska", "12"));
                Vehicle vehicleToRent = vehicleRepository.GetVehicleByIndex(0);
                DateTime rentStartDateTime = DateTime.Now;

                // Wywołanie testowanej operacji
                Rent rent = new Rent(client, vehicleToRent, rentStartDateTime);
                currentRentsRepository.AddRent(rent);

                // Sprawdzenie oczekiwanych rezultatów
                Assert.IsFalse(vehicleToRent.IsAvailable);
            }

            public void TC2()
            {
                Address address = new Address("Krakow", "Wolska", "12");
                Client client = new Client(ClientType.Standard, "Weronika", "Lindel", "49038", address);
                Vehicle vehicle = new Vehicle(VehicleSegment.A, 1000.50, 560.76, "NM5618");
                DateTime dateTime = new DateTime(2023, 07, 23);
                Rent renta = new Rent(client, vehicle, dateTime);
                client.Rent = renta;
                Assert.Throws<ArgumentOutOfRangeException>(() => renta.ReturnVehicle(new DateTime(2023, 05, 08)));

            }
        }
    }
}
