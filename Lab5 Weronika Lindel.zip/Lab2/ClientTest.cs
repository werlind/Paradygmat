﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankAccountProject;
using NUnit.Framework;
using Paradygmaty_1.model;

namespace Lab2
{
    internal class ClientTest
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        { //Arrange
            Client milionnaire = new Client(ClientType.Standard, "Jan", "Kowalski", "12345678901", new Lab3.Address("Wroclaw", "Majowka", "13"));
            
            string expectedFirstName = milionnaire.FirstName;
            string expectedLastName =  milionnaire.LastName;
           //Act
            milionnaire.FirstName = " ";
            milionnaire.LastName = " ";

            //Assert
            Assert.AreEqual(expectedFirstName, milionnaire.FirstName);
            Assert.AreEqual(expectedLastName, milionnaire.LastName);

        }
        // sprawdzic czy po ustawieniu wartosci dla dwoch property ktore maja set wartosc pozostanie niezmienna i tyle
        public void Debit_WithValidAmount_UpdatesBalance()
        {

        }
    }
}
